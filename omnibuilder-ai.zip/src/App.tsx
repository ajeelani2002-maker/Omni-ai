import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Gamepad2, 
  Presentation, 
  FileText, 
  Video, 
  Send, 
  Loader2, 
  Sparkles,
  Copy,
  Check,
  Download,
  Terminal,
  Layers,
  Layout,
  Type
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { generateOutput, GenerationResult, OutputType } from "./services/gemini";
import { cn } from "@/lib/utils";

export default function App() {
  const [prompt, setPrompt] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<GenerationResult | null>(null);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setIsLoading(true);
    try {
      const data = await generateOutput(prompt);
      setResult(data);
    } catch (error) {
      console.error("Generation failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getIcon = (type: OutputType) => {
    switch (type) {
      case "roblox": return <Gamepad2 className="w-5 h-5" />;
      case "powerpoint": return <Presentation className="w-5 h-5" />;
      case "word": return <FileText className="w-5 h-5" />;
      case "video": return <Video className="w-5 h-5" />;
    }
  };

  const getTypeLabel = (type: OutputType) => {
    switch (type) {
      case "roblox": return "Roblox Lua Script";
      case "powerpoint": return "Presentation Slides";
      case "word": return "Structured Document";
      case "video": return "Video Script & Scenes";
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-zinc-100 font-sans selection:bg-zinc-700">
      {/* Header */}
      <header className="border-b border-zinc-800/50 bg-black/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-zinc-100 rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-black" />
            </div>
            <h1 className="text-lg font-semibold tracking-tight">OmniBuilder AI</h1>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="border-zinc-800 text-zinc-400 font-mono text-[10px] uppercase tracking-widest">
              v1.0.0 Stable
            </Badge>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12 grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Left Column: Input */}
        <div className="lg:col-span-5 space-y-8">
          <div className="space-y-4">
            <h2 className="text-4xl font-bold tracking-tighter leading-none">
              What are we <br />
              <span className="text-zinc-500">building today?</span>
            </h2>
            <p className="text-zinc-400 text-lg max-w-md">
              Generate Roblox games, presentations, documents, or video scripts in seconds.
            </p>
          </div>

          <Card className="bg-zinc-900/50 border-zinc-800 shadow-2xl backdrop-blur-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-sm font-medium text-zinc-400 uppercase tracking-widest flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                Input Prompt
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="e.g., Create a Roblox obby game script with lava parts and checkpoints..."
                className="min-h-[200px] bg-black/40 border-zinc-800 focus:border-zinc-600 transition-colors resize-none text-zinc-200 placeholder:text-zinc-600"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
              <Button 
                onClick={handleGenerate} 
                disabled={isLoading || !prompt.trim()}
                className="w-full bg-zinc-100 text-black hover:bg-zinc-200 transition-all h-12 font-semibold text-base"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Generate Output
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: Gamepad2, label: "Roblox", desc: "Lua Scripts" },
              { icon: Presentation, label: "PowerPoint", desc: "Slide Content" },
              { icon: FileText, label: "Word", desc: "Formal Docs" },
              { icon: Video, label: "Video", desc: "Scripts & Scenes" },
            ].map((item, i) => (
              <div key={i} className="p-4 rounded-xl border border-zinc-800/50 bg-zinc-900/20 hover:bg-zinc-900/40 transition-colors group cursor-default">
                <item.icon className="w-5 h-5 text-zinc-500 group-hover:text-zinc-100 transition-colors mb-2" />
                <div className="text-sm font-medium text-zinc-300">{item.label}</div>
                <div className="text-[10px] text-zinc-600 uppercase tracking-wider">{item.desc}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Output */}
        <div className="lg:col-span-7">
          <AnimatePresence mode="wait">
            {result ? (
              <motion.div
                key="result"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
              >
                <Card className="bg-zinc-900/50 border-zinc-800 shadow-2xl overflow-hidden min-h-[600px] flex flex-col">
                  <CardHeader className="border-b border-zinc-800/50 bg-black/20 px-8 py-6">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="p-2 bg-zinc-800 rounded-md">
                          {getIcon(result.type)}
                        </div>
                        <Badge variant="secondary" className="bg-zinc-800 text-zinc-300 hover:bg-zinc-800 border-none">
                          {getTypeLabel(result.type)}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="icon" onClick={copyToClipboard} className="text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800">
                          {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                        </Button>
                        <Button variant="ghost" size="icon" className="text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <CardTitle className="text-2xl font-bold tracking-tight text-zinc-100">
                      {result.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0 flex-1 flex flex-col">
                    <ScrollArea className="flex-1 p-8">
                      <div className={cn(
                        "prose prose-invert max-w-none",
                        result.type === "roblox" ? "font-mono text-sm leading-relaxed" : "font-sans text-base leading-7"
                      )}>
                        {result.type === "roblox" ? (
                          <pre className="p-6 rounded-lg bg-black/60 border border-zinc-800/50 overflow-x-auto">
                            <code className="text-zinc-300 whitespace-pre-wrap">
                              {result.content}
                            </code>
                          </pre>
                        ) : result.type === "powerpoint" ? (
                          <div className="space-y-8">
                            {result.content.split(/Slide \d+:/i).filter(Boolean).map((slide, i) => (
                              <div key={i} className="p-8 rounded-2xl bg-zinc-800/30 border border-zinc-700/30 relative overflow-hidden group">
                                <div className="absolute top-4 right-6 text-[40px] font-bold text-zinc-700/20 select-none">
                                  {i + 1}
                                </div>
                                <div className="relative z-10 whitespace-pre-wrap text-zinc-200">
                                  {slide.trim()}
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="whitespace-pre-wrap text-zinc-300">
                            {result.content}
                          </div>
                        )}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full min-h-[600px] border-2 border-dashed border-zinc-800 rounded-3xl flex flex-col items-center justify-center text-center p-12 space-y-6"
              >
                <div className="w-20 h-20 bg-zinc-900 rounded-full flex items-center justify-center border border-zinc-800">
                  <Sparkles className="w-10 h-10 text-zinc-700" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold text-zinc-300">No output generated yet</h3>
                  <p className="text-zinc-500 max-w-xs mx-auto">
                    Enter a prompt on the left to start building your next project with OmniBuilder AI.
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/50 py-12 mt-12">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 text-zinc-500 text-sm">
            <Sparkles className="w-4 h-4" />
            <span>Powered by Gemini 3.1 Pro</span>
          </div>
          <div className="flex items-center gap-8 text-zinc-500 text-xs uppercase tracking-widest font-medium">
            <a href="#" className="hover:text-zinc-100 transition-colors">Documentation</a>
            <a href="#" className="hover:text-zinc-100 transition-colors">API Reference</a>
            <a href="#" className="hover:text-zinc-100 transition-colors">Privacy</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
