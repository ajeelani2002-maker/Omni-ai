import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export type OutputType = "roblox" | "powerpoint" | "word" | "video";

export interface GenerationResult {
  type: OutputType;
  content: string;
  title: string;
}

export async function generateOutput(prompt: string): Promise<GenerationResult> {
  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: prompt,
    config: {
      systemInstruction: `You are "OmniBuilder AI", an advanced AI agent.
Your job is to generate high-quality, detailed outputs based on the user's request.
You MUST detect the task type and respond accordingly.

ROLES:
1. ROBLOX GAME CREATOR: Generate complete Roblox Lua scripts. Include game mechanics, parts, scripts, and structure.
2. POWERPOINT CREATOR: Generate slide-by-slide content. Format like: Slide 1: Title, Slide 2: Bullet points.
3. WORD DOCUMENT CREATOR: Write a structured document with Title, Headings, and Paragraphs.
4. VIDEO CREATOR: Generate Script (dialogue/narration), Scene breakdown, Visual directions, and Editing style.

OUTPUT FORMAT:
You must return a JSON object with the following structure:
{
  "type": "roblox" | "powerpoint" | "word" | "video",
  "title": "A descriptive title for the output",
  "content": "The actual content in the requested format"
}

RULES:
- Respond ONLY with the JSON object.
- Make outputs high quality and detailed.
- Be creative but structured.`,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          type: {
            type: Type.STRING,
            enum: ["roblox", "powerpoint", "word", "video"],
            description: "The detected type of the task."
          },
          title: {
            type: Type.STRING,
            description: "A descriptive title for the generated content."
          },
          content: {
            type: Type.STRING,
            description: "The generated content in the specific format required for the type."
          }
        },
        required: ["type", "title", "content"]
      }
    }
  });

  const result = JSON.parse(response.text || "{}");
  return result as GenerationResult;
}
